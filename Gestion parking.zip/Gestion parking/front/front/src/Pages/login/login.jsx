import React from "react";

import Login from "../../Components/login/login";
const PageLogin= () => {
  return (
    <div>
      <Login />
    </div>
  );
};
export default PageLogin;
