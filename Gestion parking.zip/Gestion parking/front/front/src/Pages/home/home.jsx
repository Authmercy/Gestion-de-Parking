
import Navbar from "../../Components/navbar/Navbar";
import Sidebar from "../../Components/sidebar/Sidebar"

import Widget from "../../Components/widget/Widget";


import "./home.scss";
const PageHome = () => {
  return (
    <div className="home">
      <Sidebar />
      <div className="homeContainer">
       
        <div className="widgets">
         
        </div>
       
        
      </div>
    </div>
  );
};
export default PageHome;
