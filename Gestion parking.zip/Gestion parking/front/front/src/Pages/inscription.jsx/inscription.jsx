import React from "react";

import Inscription from "../../Components/inscription/inscription";
const PageInscription = () => {
  return (
    <div>
      <Inscription />
    </div>
  );
};
export default PageInscription;
